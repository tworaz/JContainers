#pragma once

UInt32 ResolveModIndex(UInt32 modIndex);
void Init_CoreSerialization_Callbacks();
