#include "skse64/PapyrusNativeFunctions.h"

void NativeFunction::DebugRunHook(VMValue * baseValue, VMClassRegistry * registry, UInt32 arg2, VMValue * resultValue, VMState * state)
{
	//
}
