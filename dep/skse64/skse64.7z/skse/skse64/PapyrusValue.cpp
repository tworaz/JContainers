#include "skse64/PapyrusValue.h"
